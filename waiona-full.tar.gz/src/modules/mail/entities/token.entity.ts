import {
    Entity,
    Column,
    ManyToOne,
    JoinColumn,
    Index,
  } from 'typeorm';
  
  import { BaseEntity } from 'src/common/entities/base.entity';
  import { UserEntity } from 'src/modules/users/entities/user.entity';
  import { TokenType } from '../enum/token-type.enum';

  @Entity('tokens')
  @Index(['token'], { unique: true })
  @Index(['userId', 'type'])
  export class TokenEntity extends BaseEntity {
  
    @Column({ type: 'varchar', length: 255, nullable: false, unique: true })
    token: string;
  
    @Column({ type: 'enum', enum: TokenType, nullable: false })
    type: TokenType;
  
    @Column({ name: 'user_id', type: 'int', nullable: false })
    userId: number;
  
    @ManyToOne(() => UserEntity, { nullable: false, onDelete: 'CASCADE' })
    @JoinColumn({ name: 'user_id' })
    user: UserEntity;
  
    @Column({ name: 'expires_at', type: 'timestamptz', nullable: false })
    expiresAt: Date;
  
    @Column({ name: 'used_at', type: 'timestamptz', nullable: true })
    usedAt: Date | null;
  
    get isExpired(): boolean {
      return new Date() > this.expiresAt;
    }
  
    get isUsed(): boolean {
      return this.usedAt !== null;
    }
  }